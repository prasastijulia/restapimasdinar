<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Main content -->
	<section class="content">
		<div class="box box-primary flat">
			<div class="box-header with-border">
				<h3 class="box-title"><strong>List Lisensi</strong></h3>
			</div>
			<div class="box-body">
				<table class="table table-striped table-hover">
					<thead>
						<tr>
							<th>Email</th>
							<th>Key</th>
							<th>Lisensi</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<th>Email</th>
							<th>Key</th>
							<th>Lisensi</th>
							<th>Aksi</th>
						</tr>
					</tfoot>
					<tbody>
						<?php foreach ($list_lisensi as $item) : ?>
						<tr>
							<td><?= $item->user_email ?></td>
							<td><?= $item->key ?></td>
							<td><?= $item->license ?></td>
							<td>
								<a href="" class="btn btn-danger btn-xs flat" data-toggle="tooltip" data-placement="top" title="Hapus"><i class="fa fa-trash fa-fw"></i></a>
							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</section>
	<!-- /.content -->
</div>
<!-- /.content-wrapper -->
