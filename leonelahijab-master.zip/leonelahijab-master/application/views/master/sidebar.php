<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
	<!-- sidebar: style can be found in sidebar.less -->
	<section class="sidebar">
		<!-- Sidebar user panel (optional) -->
		<div class="user-panel">
			<div class="pull-left image">
				<img src="http://i.imgur.com/bKoVAzA.png" class="img-circle" alt="User Image">
			</div>
			<div class="pull-left info">
				<p>Alexander Pierce</p>
				<!-- Status -->
				<a href="#"><i class="fa fa-circle text-success"></i> Online</a>
			</div>
		</div>
		<!-- Sidebar Menu -->
		<ul class="sidebar-menu">
			<li class="header">MENU NAVIGATION</li>
			<li><a href="<?= base_url() ?>"><i class="fa fa-list fa-fw"></i> <span>List Lisensi</span></a></li>
			<li><a href="<?= base_url('generate') ?>"><i class="fa fa-refresh fa-fw"></i> <span>Generate Lisensi</span></a></li>
		</ul>
		<!-- /.sidebar-menu -->
	</section>
	<!-- /.sidebar -->
</aside>
