<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_lisensi extends CI_Model {

	public $prefix = 'wp8a_';
	public $CI;

	public function __construct()
	{
		parent::__construct();
		$this->CI =& get_instance();
	}

	public function list_license()
	{
		return $this->db->get('license')->result();
	}

	public function list_unlicensed()
	{
		$this->db->select('u.user_email');
		$this->db->where("u.user_email not in (select user_email from {$this->prefix}license)");
		return $this->db->get('users u')->result();
	}

	public function genrate_license()
	{
		$this->CI->load->helper('string');
		$unlicensed = $this->list_unlicensed();
		$result = array();
		foreach ($unlicensed as $item) :
			$key = random_string('alnum',20);
			$email = $item->user_email;
			$result[] = array(
				'user_email'	=> $email,
				'key'			=> $key,
				'license'		=> md5("{$email}{$key}")
				);
		endforeach;
		if ($result) return $this->db->insert_batch('license', $result);
		return FALSE;
	}

	public function license_validation($data)
	{
		$this->db->where('key', $data['key']);
		$this->db->where('license', $data['lisensi']);
		return $this->db->get('license')->result();
	}
}
