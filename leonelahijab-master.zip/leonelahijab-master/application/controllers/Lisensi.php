<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lisensi extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_lisensi');
	}

	public function index()
	{
		$data = array(
			'list_lisensi'	=> $this->model_lisensi->list_license()
			);
		$this->load->view('master/header', $data);
		$this->load->view('master/sidebar');
		$this->load->view('api_home');
		$this->load->view('master/footer');
	}

	public function generate_lisensi()
	{
		$this->model_lisensi->genrate_license();
		redirect(base_url());
	}

	public function lisensi_validasi()
	{
		header('Content-Type: application/json');
		$info = array(
			'lisensi'	=> 'b2f70fe7f73ebff1c16a95e81ef3170d', //$this->input->post('license'),
			'key'		=> 'UdxMPE5wNHsLnfiuoaA3', //$this->input->post('key')
			);
		$validation = TRUE; //$this->model_lisensi->license_validation($info);
		if ($validation) :
			$data = array(
				'status' => 'valid'
				);
		else :
			$data = array(
				'status' => 'invalid'
				);
		endif;
		echo json_encode($data, JSON_PRETTY_PRINT);
	}
}
