# INSTALLASI
- buka folder application/config
- rename file config-sample.php dan database-sample.php menjadi config.php dan database.php
- ubah value dari masing" file config dan database
- ubah value $prefix pada file Model_lisensi di folder application/models
- upload database wp8a_license.sql (wp8a adalah prefix tabel)
